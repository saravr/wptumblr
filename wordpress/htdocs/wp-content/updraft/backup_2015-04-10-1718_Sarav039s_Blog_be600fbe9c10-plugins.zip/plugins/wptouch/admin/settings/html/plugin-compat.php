<label class="plugins"><?php _e( "Choose which plugins are loaded for mobile requests", "wptouch-pro" ); ?></label>
<?php include( WPTOUCH_DIR . '/include/html/pro.php' ); ?>

<div id="plugin-compat-setting" class="nano">

	<div class="content">
		<p><?php _e( 'Your active plugin list is refreshing', 'wptouch-pro' ); ?>&hellip;</p>
	</div>
</div>
