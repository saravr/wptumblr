<div id="preview-bar">
	<p>WPtouch Pro <?php _e( 'Theme Preview', 'wptouch-pro' ); ?></p>
	<div class="refresher"><?php _e( 'Reload', 'wptouch-pro' ); ?></div>
</div>