Theme Name: Bauhaus
Theme URI: http://www.bravenewcode.com/wptouch/
Description: Clean, modern, functional design. Great for all types of WordPress sites.
Version: 1.4.6
Stable tag: 1.4.6
Depends on: 3.7.3
Author: BraveNewCode Inc.
Parent: Foundation
Tags: smartphone


== Changelog ==

= Version 1.4.6 (March 5, 2015) =

* Changed: More robust icon naming

= Version 1.4.5 (December 11, 2014) =

* Changed: Icon font renamed from fontello to wptouch-icons

= Version 1.4.4 =

* Changed: Element padding to provide better compatibility with elements added to the_content by filters
* Added: Better support for Shortcodes Ultimate

= Version 1.4.3 =

* Changed: Switch from FontAwesome to Fontello for icons