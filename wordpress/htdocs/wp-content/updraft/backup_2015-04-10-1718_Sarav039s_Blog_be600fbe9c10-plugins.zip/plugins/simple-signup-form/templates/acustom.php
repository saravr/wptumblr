<?php
print('
<div class="pop-up-screen">
	 <div class="pop-up-content">
		<h3>Thank you...</h3>
		<p>for downloading this plugin. Simple Signup Form Free is a limited version, even you can reach many of options. If you really would like to get much more customization possibilities, purchase the <a target="_blank" href="http://pantherius.com/simple-signup-form/">PRO version</a> for only a one-time fee: $18</p>
		<blockquote>This is a solid solution! It is very effective too! I was getting 1 newsletter sign up every 1.9 days. I am now consistently getting 10 email sign ups every day. This is with about 250 visits per day. Full disclosure my solution before required customers to register now they can signup without having to!<cite>jeremy11allen 
<img src="'.plugins_url( '/assets/img/fivestar.jpg' , __FILE__ ).'"/>

</cite></blockquote>
		<h4>Pro Version Features</h4>
		<div class="half">
		<ul>
			<li>- Integration with MailChimp, Active Campaign, Benchmark, Campaign Monitor, Campayn, Constant Contact, Freshmail, GetResponse, Mad Mimi, MyMail, SimplyCast, YMLP</li>
			<li>- Subscription with Google Plus & Facebook</li>
			<li>- HTML content in the form, YouTube Integration</li>
			<li>- Bottom line text and removed copyright notice</li>
			<li>- More animation effects and flexible positions</li>
			<li>- Unlimited custom text fields, Tracking Forms with Google Analytics</li>
			<li>- Free Support & Updates</li>
		</ul>
		</div>
		<div class="half">
			<iframe class="delayed" src="//www.youtube.com/embed/gRgZnZz_Tj4?version=3&amp;autoplay=0&amp;showinfo=0&amp;loop=0&amp;controls=0&amp;playlist=gRgZnZz_Tj4" width="400" height="225" frameborder="0" allowfullscreen="allowfullscreen"></iframe>
		</div>
		<a class="close button button-default" href="#">Use Free Version</a>
		<a class="close button button-primary" href="http://codecanyon.net/item/simple-signup-wordpress-email-subscription-form/7644126?ref=pantherius">Purchase PRO Version - $18</a>
		<p class="foot">Note: Don\'t forget to remove the free version before installing the PRO version.</p>
	 </div>
</div>
<div class="overlay"></div>
');
?>