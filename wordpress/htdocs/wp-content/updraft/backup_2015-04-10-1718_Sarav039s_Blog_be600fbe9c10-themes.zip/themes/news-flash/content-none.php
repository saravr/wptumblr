<div  <?php post_class(); ?>>
    <h2 class="entry-title">Nothing Found</h2>
    
    <div class="entry-content">Nothing Found</div>
</div>

 