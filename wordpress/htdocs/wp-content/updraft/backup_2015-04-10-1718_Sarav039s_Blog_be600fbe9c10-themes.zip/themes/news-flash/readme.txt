= News Flash =

* by the WP Eden, http://wpeden.com
* News Flash - WordPress Theme, Copyright 2013 wpeden.com
* News Flash - WordPress Theme is distributed under the terms of the GNU GPL

== Notes ==
* 1st post in home or archive page uses different style and comes from template part "slider.php"

== License ==
* News Flash is released under GNU General Public License.
* Screenshot images are taken from http://pixabay.com/ , License: CC0 Public domain
    Image URLs:
    http://pixabay.com/en/sunset-evening-sky-nature-clouds-234925/
    http://pixabay.com/en/art-gallery-easel-art-objects-245251/
    http://pixabay.com/en/play-start-video-button-glossy-158609/
    http://pixabay.com/en/music-headphones-listen-mp3-audio-84874/
* Bootstrap by Twitter and the Glyphicon set are licensed under the GPL-compatible [http://www.apache.org/licenses/LICENSE-2.0 Apache License v2.0]
* Fonts:
	PT Sans licensed under [https://www.google.com/fonts/specimen/PT+Sans  SIL Open Font License (OFL)]
* less.js licensed under GPL-compatible  [https://github.com/less/less.js/blob/master/LICENSE Apache License V2], development version is available here https://github.com/less/less.js
 
* Chosen javascript library licensed under GPL-compatible [https://github.com/harvesthq/chosen/blob/master/LICENSE.md MIT license]
* All other images, css, js files included with this theme are created by me and licensed under the GPL
