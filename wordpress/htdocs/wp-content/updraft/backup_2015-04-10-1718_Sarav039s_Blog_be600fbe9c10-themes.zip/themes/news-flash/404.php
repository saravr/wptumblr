<?php get_header(); ?>     
<div class="container">
<div class="row-fluid">
<div class="span12">
<div  id="single-post">
 
 <div class="clear"></div>
<h1 class="entry-title">404, Page not found!</h1>
<div class="entry-content">

Nothing found here!  
</div>
 
</div>
 
 
</div>
</div>
 
</div>


         

<?php get_footer(); ?>
