/*!
 * Kopa load google fonts (http://kopatheme.com)
 * Copyright 2014 Kopasoft.
 * Licensed under GNU General Public License v3
 */


WebFont.load({
    google: {
        families: ['Rokkitt','Open+Sans']
    }
});